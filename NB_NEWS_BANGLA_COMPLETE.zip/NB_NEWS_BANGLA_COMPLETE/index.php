<?php
require __DIR__ . '/config.php';

$page = (string)($_GET['page'] ?? 'home');
$allowedPages = ['home','video','add','myposts','profile'];
if (!in_array($page, $allowedPages, true)) $page = 'home';
$notice = flash();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $action = (string)($_POST['action'] ?? '');
    try {
        if ($action === 'register') {
            $username = trim((string)($_POST['username'] ?? ''));
            $displayName = trim((string)($_POST['display_name'] ?? ''));
            $password = (string)($_POST['password'] ?? '');
            if (!preg_match('/^[a-zA-Z0-9_]{3,24}$/', $username)) throw new RuntimeException('ইউজারনেম ৩–২৪ অক্ষরের ইংরেজি অক্ষর, সংখ্যা বা _ হতে হবে।');
            if (mb_strlen($displayName) < 2 || mb_strlen($displayName) > 50) throw new RuntimeException('নাম ২–৫০ অক্ষরের মধ্যে দিন।');
            if (strlen($password) < 8) throw new RuntimeException('পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের দিন।');
            $stmt = $pdo->prepare('INSERT INTO users(username,password_hash,display_name,created_at) VALUES(?,?,?,?)');
            $stmt->execute([$username, password_hash($password, PASSWORD_DEFAULT), $displayName, date('Y-m-d H:i:s')]);
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$pdo->lastInsertId();
            $_SESSION['display_name'] = $displayName;
            flash('অ্যাকাউন্ট তৈরি হয়েছে। স্বাগতম!');
            safe_redirect('index.php?page=profile');
        } elseif ($action === 'login') {
            $username = trim((string)($_POST['username'] ?? ''));
            $password = (string)($_POST['password'] ?? '');
            $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            if (!$user || !password_verify($password, $user['password_hash'])) throw new RuntimeException('ইউজারনেম অথবা পাসওয়ার্ড ভুল।');
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['display_name'] = $user['display_name'];
            flash('সফলভাবে লগইন হয়েছে।');
            safe_redirect('index.php?page=profile');
        } elseif ($action === 'logout') {
            $_SESSION = [];
            if (ini_get('session.use_cookies')) {
                $params = session_get_cookie_params();
                setcookie(session_name(), '', time()-42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
            }
            session_destroy();
            header('Location: index.php'); exit;
        } elseif ($action === 'create_post') {
            require_login();
            $title = trim((string)($_POST['title'] ?? ''));
            $body = trim((string)($_POST['body'] ?? ''));
            $type = (string)($_POST['media_type'] ?? 'image');
            if (mb_strlen($title) < 2 || mb_strlen($title) > 120) throw new RuntimeException('শিরোনাম ২–১২০ অক্ষরের মধ্যে দিন।');
            if (!in_array($type, ['image','video'], true)) throw new RuntimeException('ছবি বা ভিডিও নির্বাচন করুন।');
            if (empty($_FILES['media']['name'])) throw new RuntimeException('গ্যালারি থেকে ছবি/ভিডিও নির্বাচন করুন অথবা ক্যামেরা দিয়ে রেকর্ড করুন।');
            $path = upload_media($_FILES['media'], $type);
            $now = date('Y-m-d H:i:s');
            $stmt = $pdo->prepare('INSERT INTO posts(user_id,title,body,media_path,media_type,created_at,updated_at) VALUES(?,?,?,?,?,?,?)');
            $stmt->execute([current_user_id(), $title, $body, $path, $type, $now, $now]);
            flash('পোস্ট প্রকাশ হয়েছে।');
            safe_redirect('index.php?page=myposts');
        } elseif ($action === 'delete_post') {
            require_login();
            $id = (int)($_POST['post_id'] ?? 0);
            $stmt = $pdo->prepare('SELECT * FROM posts WHERE id=? AND user_id=?');
            $stmt->execute([$id, current_user_id()]);
            $post = $stmt->fetch();
            if (!$post) throw new RuntimeException('পোস্টটি পাওয়া যায়নি অথবা এটি আপনার পোস্ট নয়।');
            $pdo->prepare('DELETE FROM posts WHERE id=? AND user_id=?')->execute([$id,current_user_id()]);
            delete_media_file($post['media_path']);
            flash('পোস্ট মুছে ফেলা হয়েছে.');
            safe_redirect('index.php?page=myposts');
        } elseif ($action === 'edit_post') {
            require_login();
            $id = (int)($_POST['post_id'] ?? 0);
            $title = trim((string)($_POST['title'] ?? ''));
            $body = trim((string)($_POST['body'] ?? ''));
            if (mb_strlen($title) < 2 || mb_strlen($title) > 120) throw new RuntimeException('শিরোনাম ২–১২০ অক্ষরের মধ্যে দিন।');
            $stmt = $pdo->prepare('SELECT * FROM posts WHERE id=? AND user_id=?');
            $stmt->execute([$id,current_user_id()]);
            $post = $stmt->fetch();
            if (!$post) throw new RuntimeException('পোস্টটি পাওয়া যায়নি।');
            $path = $post['media_path'];
            $type = $post['media_type'];
            if (!empty($_FILES['media']['name'])) {
                $newPath = upload_media($_FILES['media'], $type);
                delete_media_file($path);
                $path = $newPath;
            }
            $stmt = $pdo->prepare('UPDATE posts SET title=?, body=?, media_path=?, updated_at=? WHERE id=? AND user_id=?');
            $stmt->execute([$title,$body,$path,date('Y-m-d H:i:s'),$id,current_user_id()]);
            flash('পোস্ট আপডেট হয়েছে।');
            safe_redirect('index.php?page=myposts');
        }
    } catch (Throwable $e) {
        $notice = $e instanceof PDOException && str_contains(strtolower($e->getMessage()), 'unique')
            ? 'এই ইউজারনেম আগে থেকেই নেওয়া হয়েছে।' : $e->getMessage();
    }
}

$editPost = null;
if ($page === 'add') require_login();
if ($page === 'myposts') require_login();
if ($page === 'add' && isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM posts WHERE id=? AND user_id=?');
    $stmt->execute([(int)$_GET['edit'],current_user_id()]);
    $editPost = $stmt->fetch() ?: null;
    if (!$editPost) { $notice = 'এডিট করার পোস্টটি পাওয়া যায়নি।'; $page = 'myposts'; }
}

if ($page === 'video') {
    $stmt = $pdo->prepare("SELECT posts.*, users.display_name FROM posts JOIN users ON users.id=posts.user_id WHERE media_type='video' ORDER BY id DESC LIMIT 100");
    $stmt->execute(); $posts = $stmt->fetchAll();
} elseif ($page === 'myposts' && logged_in()) {
    $stmt = $pdo->prepare('SELECT posts.*, users.display_name FROM posts JOIN users ON users.id=posts.user_id WHERE user_id=? ORDER BY id DESC');
    $stmt->execute([current_user_id()]); $posts = $stmt->fetchAll();
} elseif ($page === 'home') {
    $posts = $pdo->query('SELECT posts.*, users.display_name FROM posts JOIN users ON users.id=posts.user_id ORDER BY posts.id DESC LIMIT 100')->fetchAll();
} else $posts = [];

function render_post(array $post, bool $own = false): void {
?>
<article class="post-card">
  <div class="post-author"><div class="avatar"><?=e(mb_substr($post['display_name'],0,1,'UTF-8'))?></div><div><strong><?=e($post['display_name'])?></strong><small><?=e(date('d M Y, h:i A', strtotime($post['created_at'])))?></small></div></div>
  <h2><?=e($post['title'])?></h2>
  <?php if ($post['media_type'] === 'video'): ?>
    <video class="post-media" controls playsinline preload="metadata" src="<?=e($post['media_path'])?>"></video>
  <?php else: ?>
    <img class="post-media" src="<?=e($post['media_path'])?>" alt="<?=e($post['title'])?>" loading="lazy">
  <?php endif; ?>
  <?php if (trim($post['body']) !== ''): ?><p class="post-body"><?=nl2br(e($post['body']))?></p><?php endif; ?>
  <?php if ($own): ?>
    <div class="post-actions"><a class="button secondary" href="index.php?page=add&edit=<?=(int)$post['id']?>">এডিট</a>
    <form method="post" onsubmit="return confirm('এই পোস্টটি স্থায়ীভাবে মুছে ফেলবেন?')"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="delete_post"><input type="hidden" name="post_id" value="<?=(int)$post['id']?>"><button class="button danger">ডিলিট</button></form></div>
  <?php endif; ?>
</article>
<?php } ?>
<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#101827">
<title><?=e(SITE_NAME)?> — <?=e(ucfirst($page))?></title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar"><a class="brand" href="index.php"><span class="brand-mark">NB</span><span><?=e(SITE_NAME)?><small><?=e(SITE_TAGLINE)?></small></span></a><a class="top-add" href="index.php?page=add">＋ পোস্ট</a></header>
<?php if ($notice): ?><div class="notice"><?=e($notice)?></div><?php endif; ?>
<main class="container">
<?php if ($page === 'home' || $page === 'video' || $page === 'myposts'): ?>
  <div class="page-heading"><div><p class="eyebrow">NB COMMUNITY</p><h1><?= $page==='video'?'ভিডিও':($page==='myposts'?'আমার পোস্ট':'সবার পোস্ট') ?></h1><p class="muted"><?= $page==='video'?'কমিউনিটির শেয়ার করা ভিডিও':($page==='myposts'?'আপনার প্রকাশিত পোস্টগুলো':'ছবি ও ভিডিও শেয়ার করুন, সবার পোস্ট দেখুন') ?></p></div></div>
  <?php if (!$posts): ?><section class="empty"><div class="empty-icon">▧</div><h2>এখনো কোনো পোস্ট নেই</h2><p>প্রথম পোস্টটি আপনি তৈরি করতে পারেন।</p><a class="button primary" href="index.php?page=add">＋ পোস্ট তৈরি করুন</a></section>
  <?php else: ?><section class="feed"><?php foreach($posts as $post) render_post($post, $page==='myposts'); ?></section><?php endif; ?>
<?php elseif ($page === 'add'): ?>
  <section class="form-card"><p class="eyebrow">CREATE POST</p><h1><?= $editPost?'পোস্ট এডিট করুন':'নতুন পোস্ট তৈরি করুন' ?></h1><p class="muted">গ্যালারি থেকে মিডিয়া নিন অথবা ক্যামেরা দিয়ে ছবি/ভিডিও তুলুন।</p>
  <form method="post" enctype="multipart/form-data" id="postForm">
    <input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>">
    <input type="hidden" name="action" value="<?=$editPost?'edit_post':'create_post'?>">
    <?php if($editPost): ?><input type="hidden" name="post_id" value="<?=(int)$editPost['id']?>"><input type="hidden" id="existingType" value="<?=e($editPost['media_type'])?>"><?php endif; ?>
    <label for="title">শিরোনাম</label><input id="title" name="title" maxlength="120" required value="<?=e($editPost['title']??'')?>" placeholder="পোস্টের শিরোনাম লিখুন">
    <label for="body">বিস্তারিত (ঐচ্ছিক)</label><textarea id="body" name="body" rows="4" placeholder="কিছু লিখতে চাইলে লিখুন..."><?=e($editPost['body']??'')?></textarea>
    <?php if(!$editPost): ?><label>মিডিয়ার ধরন</label><div class="type-choice"><label><input type="radio" name="media_type" value="image" checked> ছবি</label><label><input type="radio" name="media_type" value="video"> ভিডিও</label></div><?php else: ?><p class="muted">বর্তমান মিডিয়া: <?= $editPost['media_type']==='video'?'ভিডিও':'ছবি' ?> (ধরন পরিবর্তন করতে হলে নতুন পোস্ট দিন)</p><?php endif; ?>
    <div class="picker-grid">
      <label class="picker"><span class="picker-icon">▧</span><strong>গ্যালারি থেকে</strong><small>ছবি বা ভিডিও বাছাই</small><input type="file" id="galleryInput" name="media" accept="image/*,video/*" <?= $editPost?'':'required' ?>></label>
      <label class="picker"><span class="picker-icon">◎</span><strong>ক্যামেরা</strong><small>ছবি/ভিডিও ক্যাপচার</small><input type="file" id="cameraInput" accept="image/*,video/*" capture="environment"></label>
    </div>
    <p class="hint">সর্বোচ্চ ফাইল সাইজ 50 MB। ভিডিও সর্বোচ্চ 3 মিনিট (180 সেকেন্ড)। কিছু ফোনে ক্যামেরার অপশন আলাদা দেখা যেতে পারে।</p>
    <div id="preview" class="preview"><?php if($editPost): ?>বর্তমান মিডিয়া: <a href="<?=e($editPost['media_path'])?>" target="_blank" rel="noopener">দেখুন</a><?php else: ?>মিডিয়া বাছাই করলে এখানে প্রিভিউ দেখা যাবে।<?php endif; ?></div>
    <button class="button primary full" type="submit"><?=$editPost?'পরিবর্তন সেভ করুন':'পোস্ট প্রকাশ করুন'?></button>
  </form>
  </section>
<?php elseif ($page === 'profile'): ?>
  <section class="form-card profile-card"><p class="eyebrow">YOUR ACCOUNT</p><h1>প্রোফাইল</h1>
  <?php if (logged_in()): ?><div class="profile-info"><div class="profile-avatar"><?=e(mb_substr((string)($_SESSION['display_name']??'U'),0,1,'UTF-8'))?></div><h2><?=e((string)$_SESSION['display_name'])?></h2><p class="muted">আপনি লগইন অবস্থায় আছেন।</p></div><a class="button primary full" href="index.php?page=myposts">আমার পোস্ট দেখুন</a><form method="post" class="logout-form"><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="logout"><button class="button secondary full">লগআউট</button></form>
  <?php else: ?><div class="auth-grid"><form method="post"><h2>লগইন</h2><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="login"><label>ইউজারনেম</label><input name="username" required autocomplete="username"><label>পাসওয়ার্ড</label><input type="password" name="password" required autocomplete="current-password"><button class="button primary full">লগইন</button></form><form method="post"><h2>নতুন অ্যাকাউন্ট</h2><input type="hidden" name="csrf_token" value="<?=e(csrf_token())?>"><input type="hidden" name="action" value="register"><label>আপনার নাম</label><input name="display_name" required maxlength="50"><label>ইউজারনেম</label><input name="username" required minlength="3" maxlength="24" pattern="[A-Za-z0-9_]+" autocomplete="username"><label>পাসওয়ার্ড (কমপক্ষে ৮ অক্ষর)</label><input type="password" name="password" required minlength="8" autocomplete="new-password"><button class="button primary full">অ্যাকাউন্ট খুলুন</button></form></div><?php endif; ?>
  </section>
<?php endif; ?>
</main>
<nav class="bottom-nav">
<a class="<?=$page==='home'?'active':''?>" href="index.php"><span>⌂</span><small>হোম</small></a>
<a class="<?=$page==='video'?'active':''?>" href="index.php?page=video"><span>▷</span><small>ভিডিও</small></a>
<a class="add-nav <?=$page==='add'?'active':''?>" href="index.php?page=add"><span>＋</span><small>পোস্ট</small></a>
<a class="<?=$page==='myposts'?'active':''?>" href="index.php?page=myposts"><span>▤</span><small>আমার পোস্ট</small></a>
<a class="<?=$page==='profile'?'active':''?>" href="index.php?page=profile"><span>◉</span><small>প্রোফাইল</small></a>
</nav>
<script src="assets/app.js"></script>
</body></html>
