NB NEWS BANGLA — COMPLETE PHP WEBSITE
=====================================

FEATURES
- Mobile-friendly Bangla interface
- Home feed, Video feed, Add Post, My Posts, Profile
- User registration and login
- Upload photos from phone gallery
- Choose camera capture on supported phones
- Image/video preview before publishing
- Create, edit and delete your own posts
- Video duration checked in browser: maximum 3 minutes
- 50 MB upload limit in application code
- SQLite database auto-created on first visit
- CSRF protection and password hashing

REQUIREMENTS
- PHP 8.0+ recommended
- PDO SQLite extension enabled
- Fileinfo extension enabled
- Hosting must allow PHP uploads and writing to this folder
- Set PHP upload_max_filesize and post_max_size to at least 50M (post_max_size should be a little larger, e.g. 55M)

INSTALLATION
1. Extract this ZIP on your computer.
2. Upload all files and folders inside NB_NEWS_BANGLA_COMPLETE to the hosting public folder (often htdocs or public_html).
3. Make sure the uploads folder is writable by PHP. If needed, set folder permission to 755; use 775 only if your host requires it.
4. Open your domain in a browser. SQLite database is created automatically.
5. Open Profile, register a new account, then add a post.

IMPORTANT LIMITATIONS
- This is a community photo/video sharing starter site, not a verified-news editorial CMS.
- The 3-minute duration check happens in the browser. A user can bypass browser checks; strict server-side duration enforcement needs FFmpeg or a hosting API. The hosting's PHP upload limits also apply.
- The site does not include email verification, password reset, moderation, reporting, likes, comments, or an admin moderation dashboard.
- Before public launch, add moderation/abuse reporting and test upload limits on your hosting.
- If your hosting does not support PDO SQLite, this version will show a database error; it must be converted to MySQL for that host.
- Do not upload the ZIP itself to the website root; extract it first.
