<?php
declare(strict_types=1);
session_start();
date_default_timezone_set('Asia/Dhaka');

define('SITE_NAME', 'NB News Bangla');
define('SITE_TAGLINE', 'সত্য খবর, সবার আগে');
define('MAX_VIDEO_SECONDS', 180); // 3 minutes; change to 90 for 1.5 minutes
define('MAX_UPLOAD_BYTES', 50 * 1024 * 1024); // 50 MB
define('DB_FILE', __DIR__ . '/data.sqlite');

try {
    $pdo = new PDO('sqlite:' . DB_FILE);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec("PRAGMA foreign_keys = ON");
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        display_name TEXT NOT NULL,
        created_at TEXT NOT NULL
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        body TEXT NOT NULL DEFAULT '',
        media_path TEXT NOT NULL,
        media_type TEXT NOT NULL CHECK(media_type IN ('image','video')),
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )");
} catch (Throwable $e) {
    http_response_code(500);
    exit('Database error. Hosting-এ PHP PDO SQLite extension চালু আছে কি না দেখুন।');
}

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function logged_in(): bool { return isset($_SESSION['user_id']); }
function current_user_id(): int { return (int)($_SESSION['user_id'] ?? 0); }
function require_login(): void {
    if (!logged_in()) {
        $_SESSION['flash'] = 'এই কাজটি করতে আগে লগইন করুন।';
        header('Location: index.php?page=profile');
        exit;
    }
}
function flash(string $message = ''): string {
    if ($message !== '') { $_SESSION['flash'] = $message; return ''; }
    $value = (string)($_SESSION['flash'] ?? '');
    unset($_SESSION['flash']);
    return $value;
}
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function check_csrf(): void {
    $sent = (string)($_POST['csrf_token'] ?? '');
    if (!hash_equals((string)($_SESSION['csrf_token'] ?? ''), $sent)) {
        http_response_code(403); exit('নিরাপত্তা যাচাই ব্যর্থ হয়েছে। পেজটি রিফ্রেশ করে আবার চেষ্টা করুন।');
    }
}
function safe_redirect(string $url = 'index.php'): never {
    header('Location: ' . $url); exit;
}
function upload_media(array $file, string $mediaType): string {
    if (!isset($file['error']) || is_array($file['error'])) throw new RuntimeException('ফাইলটি সঠিক নয়।');
    if ($file['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('আপলোড ব্যর্থ হয়েছে। ফাইলের সাইজ কমিয়ে আবার চেষ্টা করুন।');
    if ((int)$file['size'] > MAX_UPLOAD_BYTES) throw new RuntimeException('ফাইল সর্বোচ্চ 50 MB হতে পারবে।');
    if (!is_uploaded_file($file['tmp_name'])) throw new RuntimeException('আপলোড করা ফাইল যাচাই করা যায়নি।');

    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    $allowed = $mediaType === 'image'
        ? ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif']
        : ['video/mp4'=>'mp4','video/webm'=>'webm','video/quicktime'=>'mov'];
    if (!isset($allowed[$mime])) throw new RuntimeException('এই ফাইল ফরম্যাটটি সমর্থিত নয়। JPG/PNG/WEBP বা MP4/WEBM ভিডিও ব্যবহার করুন।');
    if ($mediaType === 'video' && function_exists('shell_exec')) {
        // Duration is also checked in the browser. Server-side duration checking needs FFmpeg,
        // which is not available on every shared host.
    }
    $dir = __DIR__ . '/uploads';
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) throw new RuntimeException('uploads ফোল্ডার তৈরি করা যায়নি।');
    $name = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) throw new RuntimeException('ফাইল সেভ করা যায়নি।');
    return 'uploads/' . $name;
}
function delete_media_file(string $path): void {
    $prefix = 'uploads/';
    if (str_starts_with($path, $prefix)) {
        $full = __DIR__ . '/' . $path;
        if (is_file($full)) @unlink($full);
    }
}
