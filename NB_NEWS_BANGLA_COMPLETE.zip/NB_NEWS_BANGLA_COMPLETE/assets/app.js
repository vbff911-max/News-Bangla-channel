(() => {
  const form = document.getElementById('postForm');
  if (!form) return;
  const gallery = document.getElementById('galleryInput');
  const camera = document.getElementById('cameraInput');
  const preview = document.getElementById('preview');
  const typeRadios = [...document.querySelectorAll('input[name="media_type"]')];
  let objectUrl = null;

  function selectedType() {
    const chosen = typeRadios.find(r => r.checked);
    if (chosen) return chosen.value;
    return document.getElementById('existingType')?.value || 'image';
  }
  function setFile(file) {
    if (!file) return;
    const isVideo = file.type.startsWith('video/');
    const isImage = file.type.startsWith('image/');
    if (!isVideo && !isImage) {
      alert('শুধু ছবি বা ভিডিও ফাইল নির্বাচন করুন।'); return;
    }
    if (selectedType() === 'video' && !isVideo) {
      alert('ভিডিও নির্বাচন করা আছে—একটি ভিডিও ফাইল বাছাই করুন।'); return;
    }
    if (selectedType() === 'image' && !isImage) {
      alert('ছবি নির্বাচন করা আছে—একটি ছবি বাছাই করুন।'); return;
    }
    if (file.size > 50 * 1024 * 1024) {
      alert('ফাইল সর্বোচ্চ 50 MB হতে পারবে।'); return;
    }
    if (objectUrl) URL.revokeObjectURL(objectUrl);
    objectUrl = URL.createObjectURL(file);
    preview.innerHTML = '';
    const el = document.createElement(isVideo ? 'video' : 'img');
    el.src = objectUrl;
    if (isVideo) {
      el.controls = true; el.playsInline = true; el.preload = 'metadata';
      el.addEventListener('loadedmetadata', () => {
        if (Number.isFinite(el.duration) && el.duration > 180) {
          alert('ভিডিও সর্বোচ্চ 3 মিনিট (180 সেকেন্ড) হতে পারবে।');
          if (gallery) gallery.value = '';
          if (camera) camera.value = '';
          preview.textContent = 'ভিডিওটি 3 মিনিটের বেশি। ছোট ভিডিও বাছাই করুন।';
        }
      }, {once:true});
    } else {
      el.alt = 'মিডিয়া প্রিভিউ';
    }
    preview.appendChild(el);
  }
  gallery?.addEventListener('change', () => {
    if (gallery.files && gallery.files[0]) {
      if (camera) camera.value = '';
      setFile(gallery.files[0]);
    }
  });
  camera?.addEventListener('change', () => {
    if (camera.files && camera.files[0]) {
      if (gallery) gallery.value = '';
      setFile(camera.files[0]);
    }
  });
  form.addEventListener('submit', (event) => {
    const file = gallery?.files?.[0] || camera?.files?.[0];
    const editing = form.querySelector('input[name="action"]')?.value === 'edit_post';
    if (!editing && !file) {
      event.preventDefault(); alert('প্রথমে গ্যালারি বা ক্যামেরা থেকে মিডিয়া বাছাই করুন.'); return;
    }
    if (file && file.type.startsWith('video/') && selectedType() !== 'video') {
      event.preventDefault(); alert('মিডিয়ার ধরন “ভিডিও” নির্বাচন করুন।');
    }
  });
})();
